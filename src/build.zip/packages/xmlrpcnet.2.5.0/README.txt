XML-RPC.NET - XML-RPC for .NET 
v2.5.0 Release
Copyright (C) 2001-2010 Charles Cook (chascook@gmail.com)

xmlrpcgen 
Copyright (C) 2003 Joe Bork

For more information about XML-RPC.NET visit http://www.xml-rpc.net.

XML-RPC.NET is licensed with MIT X11 license.
(see http://www.xml-rpc.net/faq/xmlrpcnetfaq.html#6.12)

For more information about XML-RPC refer to http://www.xmlrpc.com/


PREQUISITES
-----------
Assembly CookComputing.XmlRpcV2.dll requires 2.0 .NET runtime 
and runs on all later versions.


DOCUMENTATION
-------------
For help on using XML-RPC.NET, see 
http://www.xml-rpc.net/faq/xmlrpcnetfaq.html.