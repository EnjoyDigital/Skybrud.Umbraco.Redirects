﻿namespace FastExcel
{
    internal class WorksheetAddSettings
    {
        public string Name { get; set; }

        public int SheetId { get; set; }

        public int InsertAfterSheetId { get; set; }
    }
}
