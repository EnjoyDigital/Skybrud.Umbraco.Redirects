﻿using Umbraco.Web.Composing;

namespace Skybrud.Umbraco.Redirects.Routing {

    public class RedirectsModule : ModuleInjector<RedirectsInjectedModule> { }

}