namespace Skybrud.Umbraco.Redirects.Models.Import
{
    public enum ImportErrorLevel
    {
        Success=0,
        Warning=1,
        Error=2
    }
}